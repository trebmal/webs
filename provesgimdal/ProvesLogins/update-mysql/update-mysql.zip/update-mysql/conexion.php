<?php
$conexion = mysql_connect("localhost", "usuario", "clave") or trigger_error(mysql_error(),E_USER_ERROR); 
mysql_select_db("nombre_base_datos", $conexion);
?>