-- 
-- Editor SQL for DB table prova
-- Created by http://editor.datatables.net/generator
-- 

CREATE TABLE `prova` (
	`id` int(10) NOT NULL auto_increment,
	`nombre` varchar(255),
	`apelidos` varchar(255),
	PRIMARY KEY( `id` )
);