-- 
-- Editor SQL for DB table usuaris3
-- Created by http://editor.datatables.net/generator
-- 

CREATE TABLE `usuaris3` (
	`id` int(10) NOT NULL auto_increment,
	`nom` varchar(255),
	`cognoms` varchar(255),
	`email` varchar(255),
	`permisos` varchar(255),
	PRIMARY KEY( `id` )
);