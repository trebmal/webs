Código para convertir una tabla HTML a una tabla estructurada con búsqueda en tiempo real, paginación, ordenamiento 
por columnas y demás utilizando el plugin jQuery DataTables, obteniendo los datos de una tabla en MySQL mediante
la clase PDO de PHP para realizar la conexión a la base de datos.

Video de como se fué construyendo este código y ejemplo aquí: http://youtu.be/i41WoX-B5f4
