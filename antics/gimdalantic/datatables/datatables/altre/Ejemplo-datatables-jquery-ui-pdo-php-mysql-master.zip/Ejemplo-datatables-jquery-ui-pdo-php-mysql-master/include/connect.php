<?php
	return new PDO('mysql:host=127.0.0.1;dbname=datatables','root','root');
?>